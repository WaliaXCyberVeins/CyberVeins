# CyberVeins by WaliaX

A premium, mobile-first cybersecurity landing site built with:
- React.js
- Tailwind CSS
- Framer Motion
- Lucide Icons

## 🚀 Setup

```bash
npm install
npm start
```

## 🌐 Deploy to GitHub Pages

```bash
npm run deploy
```
